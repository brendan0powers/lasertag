
#define PIN_SENSE 2
#define PIN_IR 3
#define PIN_FLASH 4
#define PIN_STATUS 5
#define PIN_RADIO 7
#define PIN_RED A0
#define PIN_GREEN A1
#define PIN_BLUE A2
#define PIN_TRIGGER A3
#define PIN_RELOAD A4


